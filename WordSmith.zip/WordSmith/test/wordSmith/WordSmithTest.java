package wordSmith;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class WordSmithTest
{
	private WordSmith ws;
	
	@Before 
	public void setup()
	{
		ws = new WordSmith();
	}
	
	@Test
	public void testReturnsNoneDivisibleNumberAsString()
	{
		assertEquals("1", ws.determineOutput(1));	
		assertEquals("2", ws.determineOutput(2));
		assertEquals("7", ws.determineOutput(7));
		assertEquals("31", ws.determineOutput(31));
	}
	
	@Test
	public void testReturnsWordWhenDivisibleByThree() 
	{
		assertEquals("word", ws.determineOutput(3));
		assertEquals("word", ws.determineOutput(6));
	}
	
	@Test
	public void testReturnsSmithWhenDivisibleByFive() 
	{
		assertEquals("smith", ws.determineOutput(5));
		assertEquals("smith", ws.determineOutput(10));
	}
	
	@Test
	public void testReturnsWordSmithWhenDivisibleByFifteen() 
	{
		assertEquals("wordsmith", ws.determineOutput(15));
		assertEquals("wordsmith", ws.determineOutput(30));
		assertEquals("wordsmith", ws.determineOutput(0));
	}
}
