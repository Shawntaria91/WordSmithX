package wordSmith;

public class WordSmith 
{

	 /**
	  * Determines if the word "word," "smith," or "wordsmith," should be returned based 
	  * on the integer input is divisible by 3, 5, or 15 respectively. 
	  * @param number is the input. 
	  * @return the result of "word," "smith," or "wordsmith," depending on the input.
	  */
	public String determineOutput(int number) 
	{
		if(number % 15 == 0) 
		{
			return "wordsmith";
		}
		else if(number % 3 == 0) 
		{	
			return "word";
		}
		else if(number % 5 == 0) 
		{	
			return "smith";
		}
		
		return String.valueOf(number);
	}

}
